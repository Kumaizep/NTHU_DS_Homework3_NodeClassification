Download the big-scale datasets from the repository of [LINKX](https://github.com/CUAI/Non-Homophily-Large-Scale).

